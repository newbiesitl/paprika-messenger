# Paprika Messenger compiled Worker

Service 0.5.8. This platform-neutral JavaScript module is the built server with its UI and messaging skill embedded. It requires the service's Cloudflare/Sites runtime, D1 migrations, owner authentication and event secrets. It is not a desktop executable or a complete Site deployment. Use the companion service-source package and its setup instructions to deploy or upgrade the same private Site.
